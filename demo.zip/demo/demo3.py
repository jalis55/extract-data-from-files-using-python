import numpy as np
import pandas as pd
import simplejson as json

status = []
with open('salida_tweets.txt') as file:
    for line in file:
        status.append(line)
# for i in status:
#     print(i)
sen_data=np.array(status)
print(sen_data)