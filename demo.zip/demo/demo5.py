import numpy as np
import pandas as pd
import simplejson as json



data = pd.read_csv('Sentimientos.txt',sep="\t")





sen="i fell yummy zealous"
#print(data)
data_arr=np.array(data)
#print(data_arr)
rank=0
for i in data_arr:
     #print(i[0])
     if i[0] in sen:
         rank=rank+int(i[1])
         #print(i[1])
print(rank)




