import numpy as np
import pandas as pd
import simplejson as json


#read_data=pd.read_csv('Sentimientos.txt',sep=" ",header=None)
data = pd.read_csv('Sentimientos.txt',sep="\t")


status = []
with open('salida_tweets.txt') as file:
    for line in file:
        status.append(line)
for i in status:

    #print(i)
    if 'status' in i:
        json_data=json.dumps({})
    else:
        json_data=json.dumps(i)
print(type(json_data))


# print(status)
sen="i fell yummy zealous"
#print(data)
# data_arr=np.array(data)
# # print(data_arr)
# for i in data_arr:
#     #print(i[0])
#     if i[0] in sen:
#         print(i[1])



