import numpy as np
import pandas as pd
import json
import csv

sens=['i am a good boy','Hi this is a story of bad boy','i am nobody']
demo="Hi I am jalis"
demo=demo.split()
demo.remove('Hi')
print(demo)
word_lst=[['boy',1],['bad',2],['good',3]]
sen_rank=[]
new_word=[]
new_word_lst=[]
for sen in sens:
	result=0
	sen_lst=sen.split()
	for word in word_lst:
		
		if word[0] in sen_lst:
			
			sen_lst.remove(word[0])
			result=result+word[1]
	for wrd in sen_lst:
		if wrd not in new_word:
			new_word.append(wrd)
			new_word_lst.append([wrd,result])

	sen_rank.append([sen,result])
# for i in sen_rank:
# 	print(i)
# for i in word_lst:
# 	print(i)
for i in new_word_lst:
	print(i)