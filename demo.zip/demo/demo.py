import numpy as np
import pandas as pd

#read_data=pd.read_csv('Sentimientos.txt',sep=" ",header=None)
data = pd.read_csv('Sentimientos.txt', sep="\t",names=["word","value"])
sen="i fell yummy zealous"
sen=sen.split()
len=len(sen)
print(len)
for i in sen:
    print(i)
    for j in data["word"]:
        if i==j["word"]:
            print(i)

#if data["word"] in sen:
   # print(sen)
#print(data["word"])