import numpy as np
import pandas as pd

import json
sentences=[]
with open('salida_tweets.txt') as file:
    for line in file:
        #line=line.split()
        line=json.loads(line)
        #print(type(line))
        if "delete" not in line.keys():
            sentences.append(line["text"])
word_data = pd.read_csv('Sentimientos.txt',sep="\t")
word_data=np.array(word_data)

